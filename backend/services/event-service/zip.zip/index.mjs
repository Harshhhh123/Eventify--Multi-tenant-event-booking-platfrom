import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({ region: "ap-south-1" });
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  console.log("EVENT:", JSON.stringify(event));

  if (!event.body) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "Body missing" })
    };
  }

  const body = JSON.parse(event.body);

  const item = {
    eventId: Date.now().toString(),
    title: body.title,
    description: body.description,
    date: body.date
  };

  await docClient.send(
    new PutCommand({
      TableName: "Events",
      Item: item
    })
  );

  return {
    statusCode: 201,
    body: JSON.stringify(item)
  };
};
